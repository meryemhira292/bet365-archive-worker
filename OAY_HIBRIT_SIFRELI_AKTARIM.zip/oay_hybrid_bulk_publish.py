#!/usr/bin/env python3
"""Resume-safe encrypted OAY hybrid publisher. Requires cryptography and GitHub token.
No plaintext candidate is uploaded. Never writes existing packet files.
"""
import argparse,base64,hashlib,json,os,pathlib,subprocess,sys,time,urllib.request,urllib.error,zipfile
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey,X25519PublicKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
import zlib
DOMAIN=b'OAY-HYBRID-INBOX-V1'

def sha(x):return hashlib.sha256(x).hexdigest()
def b64(x):return base64.b64encode(x).decode()
def get(url,token):
 req=urllib.request.Request(url,headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28'})
 try:
  with urllib.request.urlopen(req,timeout=90) as r:return json.loads(r.read())
 except urllib.error.HTTPError as e:
  if e.code==404:return None
  raise

def publish(path,repo,token):
 api=f'https://api.github.com/repos/{repo}/contents/oay/hybrid_inbox/{path.name}'
 content=path.read_bytes(); current=get(api,token)
 if current:
  # Immutable packet: verify the actual existing bytes, not just the name.
  if current.get('encoding')=='base64': old=base64.b64decode(current['content'])
  else:
   raw=get(current['url'],token)
   raise RuntimeError('Cannot verify existing packet bytes: '+path.name)
  if old!=content:raise RuntimeError('IMMUTABILITY CONFLICT '+path.name)
  return 'existing'
 data=json.dumps({'message':'Publish immutable encrypted OAY hybrid packet '+path.name,'content':b64(content),'branch':'main'}).encode()
 req=urllib.request.Request(api,data=data,method='PUT',headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','Content-Type':'application/json','X-GitHub-Api-Version':'2022-11-28'})
 try:
  with urllib.request.urlopen(req,timeout=120) as r:r.read()
 except urllib.error.HTTPError as e:
  if e.code in (409,422):
   other=get(api,token)
   if other and other.get('encoding')=='base64' and base64.b64decode(other['content'])==content:return 'existing'
  raise
 return 'published'

def main():
 p=argparse.ArgumentParser();p.add_argument('--gate',required=True);p.add_argument('--public-key',required=True);p.add_argument('--outdir',default='oay_hybrid_packets');p.add_argument('--rows-per-chunk',type=int,default=1000);p.add_argument('--repo',default='meryemhira292/bet365-archive-worker');p.add_argument('--publish',action='store_true');p.add_argument('--limit',type=int,default=0);a=p.parse_args()
 if not 1<=a.rows_per_chunk<=5000:raise ValueError('rows-per-chunk must be 1..5000')
 gate=pathlib.Path(a.gate);out=pathlib.Path(a.outdir);out.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(gate) as z:
  m=json.loads(z.read('MANIFEST_SHA256.json'));raw=z.read('EXACT_QUEUE.jsonl')
  if sha(raw)!=m['EXACT_QUEUE.jsonl']:raise ValueError('GATE manifest mismatch')
  rows=[json.loads(l) for l in raw.splitlines() if l.strip()]
 # Canonical bridge schema validation; no plaintext published.
 unique={};
 for row in rows:
  sig=row.get('sig');cols=row.get('cols');d=row.get('d')
  if not isinstance(sig,str) or len(sig)!=64 or any(c not in '0123456789abcdef' for c in sig) or not isinstance(cols,list) or not 6<=len(cols)<=40 or cols!=sorted(set(cols)) or not all(type(c)==int and 0<=c<256 for c in cols) or type(d)!=int or not 0<=d<=6:raise ValueError('Invalid candidate schema')
  if sig in unique and unique[sig]!=row:raise ValueError('Conflicting duplicate signature')
  unique[sig]=row
 rows=list(unique.values());source_sha=sha(gate.read_bytes());pub=X25519PublicKey.from_public_bytes(base64.b64decode(a.public_key,validate=True))
 # Only make packets that are not already present locally. Existing packets are immutable.
 packets=[]
 for i in range(0,len(rows),a.rows_per_chunk):
  index=i//a.rows_per_chunk;name=f'{source_sha[:16]}_{index:05d}.json';path=out/name
  if not path.exists():
   body=b''.join(json.dumps(r,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()+b'\n' for r in rows[i:i+a.rows_per_chunk])
   if len(body)>2_000_000:raise ValueError('Packet exceeds receiver plaintext limit: '+name)
   eph=X25519PrivateKey.generate();salt=os.urandom(16);nonce=os.urandom(12)
   key=HKDF(algorithm=hashes.SHA256(),length=32,salt=salt,info=DOMAIN).derive(eph.exchange(pub))
   packet={'schema':'oay-hybrid-inbox-v1','source_sha256':source_sha,'chunk_index':index,'rows':len(rows[i:i+a.rows_per_chunk]),'raw_sha256':sha(body),'ephemeral_public':b64(eph.public_key().public_bytes(encoding=serialization.Encoding.Raw,format=serialization.PublicFormat.Raw)),'salt':b64(salt),'nonce':b64(nonce),'ciphertext':b64(AESGCM(key).encrypt(nonce,zlib.compress(body,9),DOMAIN))}
   path.write_text(json.dumps(packet,separators=(',',':'))+'\n')
  else:
   existing=json.loads(path.read_text())
   if existing.get('source_sha256')!=source_sha or existing.get('chunk_index')!=index or existing.get('rows')!=len(rows[i:i+a.rows_per_chunk]):raise ValueError('Local immutable packet mismatch: '+name)
  packets.append(path)
 print(json.dumps({'gate_sha256':source_sha,'unique_candidates':len(rows),'encrypted_packets':len(packets),'outdir':str(out),'mode':'publish' if a.publish else 'prepare-only'}),flush=True)
 if not a.publish:return
 token=os.getenv('GH_TOKEN') or os.getenv('GITHUB_TOKEN')
 if not token:raise RuntimeError('GH_TOKEN/GITHUB_TOKEN missing. Do not put a token in repo or logs.')
 published=existing=0
 for path in packets[:a.limit or None]:
  for attempt in range(5):
   try:result=publish(path,a.repo,token);break
   except (urllib.error.HTTPError,urllib.error.URLError) as e:
    if attempt==4:raise
    time.sleep(2**attempt)
  published+=result=='published';existing+=result=='existing'
  print(f'{path.name}: {result}; published={published} already={existing}',flush=True)
 print(json.dumps({'published_new_packets':published,'already_published_packets':existing,'completed':published+existing,'total_packets':len(packets)}))
if __name__=='__main__':main()
